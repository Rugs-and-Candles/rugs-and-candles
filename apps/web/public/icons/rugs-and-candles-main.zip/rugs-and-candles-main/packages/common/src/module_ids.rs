pub const RUGS_N_CANDLES_NAMESPACE: &str = "rugsandcandles";
pub const BOARD_NAME: &str = "board";
pub const CONTROLLER_NAME: &str = "controller";
pub const BOARD_ID: &str = const_format::formatcp!("{RUGS_N_CANDLES_NAMESPACE}:{BOARD_NAME}");
pub const CONTROLLER_ID: &str =
    const_format::formatcp!("{RUGS_N_CANDLES_NAMESPACE}:{CONTROLLER_NAME}");
